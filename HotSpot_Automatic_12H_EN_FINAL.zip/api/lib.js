const cheerio=require('cheerio');
const OFFICIAL='https://www.calottery.com/en/draw-games/hot-spot/past-winning-numbers';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

function uniqSorted(nums){return [...new Set((nums||[]).map(Number))].filter(n=>n>=1&&n<=80).sort((a,b)=>a-b)}
function parse(html){
  const $=cheerio.load(html);
  const t=$('body').text().replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const no=(t.match(/Draw Number:\s*(\d{7})/i)||[])[1];
  const dm=t.match(/Draw Date:\s*([^|]+?)\s*\|\s*Draw Time:\s*([0-9:]+\s*[ap]\.??m\.?)/i);
  if(!no||!dm)return null;
  let seg=t.slice(t.indexOf(dm[0])+dm[0].length);
  const stop=seg.search(/Check out the Hot Spot|Hot Spot Payouts|Overall odds/i);
  if(stop>0)seg=seg.slice(0,stop);
  const bull=(seg.match(/Bulls[-‑–—]?eye\s+number\s+is(?:\s*\{number\})?\s*(?:number\s*)?(\d{1,2})/i)||[])[1];
  const raw=seg.match(/\b(?:[1-9]|[1-7]\d|80)\b/g)||[];
  const numbers=uniqSorted(raw.slice(0,20));
  if(numbers.length!==20)return null;
  return {id:+no,date:dm[1].trim(),time:dm[2].trim(),numbers,bullsEye:bull?Number(bull):null};
}
function valid(d){return d&&Number.isInteger(d.id)&&d.numbers?.length===20&&new Set(d.numbers).size===20&&d.numbers.every(n=>n>=1&&n<=80)&&(d.bullsEye===null||(Number.isInteger(d.bullsEye)&&d.bullsEye>=1&&d.bullsEye<=80&&d.numbers.includes(d.bullsEye)))}
async function getDraw(id){
  let last;
  for(let a=0;a<3;a++)try{
    const u=new URL(OFFICIAL);
    if(id)u.searchParams.set('query',id);
    u.searchParams.set('_v',Date.now().toString(36)+Math.random().toString(36).slice(2));
    const r=await fetch(u,{cache:'no-store',headers:{'user-agent':'Mozilla/5.0','cache-control':'no-cache','pragma':'no-cache','accept-language':'en-US,en;q=0.9'}});
    if(!r.ok)throw Error(`California Lottery HTTP ${r.status}`);
    const d=parse(await r.text());
    if(!valid(d))throw Error('Invalid parsed draw');
    if(id&&d.id!==id)throw Error(`Expected ${id}, got ${d.id}`);
    return d;
  }catch(e){last=e;await sleep(150*(a+1))}
  throw last||Error('Fetch failed');
}
async function getMany(ids){const out=[];const C=8;for(let i=0;i<ids.length;i+=C)out.push(...await Promise.all(ids.slice(i,i+C).map(getDraw)));return out.sort((a,b)=>a.id-b.id)}
function score(draw,group){const set=new Set(draw.numbers);const hit=group.filter(n=>set.has(n));const bullsEyeMatch=Number.isInteger(draw.bullsEye)&&group.includes(draw.bullsEye);return {count:hit.length,hit,bullsEye:draw.bullsEye,bullsEyeMatch};}
function sb(){const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!url||!key)throw Error('Supabase environment variables are missing');return {url:url.replace(/\/$/,''),key}}
async function db(path,{method='GET',body,prefer}={}){const {url,key}=sb();const h={'apikey':key,'authorization':`Bearer ${key}`,'content-type':'application/json'};if(prefer)h.prefer=prefer;const r=await fetch(`${url}/rest/v1/${path}`,{method,headers:h,body:body===undefined?undefined:JSON.stringify(body),cache:'no-store'});const txt=await r.text();if(!r.ok)throw Error(`Supabase ${r.status}: ${txt.slice(0,300)}`);if(!txt)return null;try{return JSON.parse(txt)}catch{return txt}}

function combos5(a,fn){const n=a.length;for(let i=0;i<n-4;i++)for(let j=i+1;j<n-3;j++)for(let k=j+1;k<n-2;k++)for(let l=k+1;l<n-1;l++)for(let m=l+1;m<n;m++)fn([a[i],a[j],a[k],a[l],a[m]])}
function mean(a){return a.length?a.reduce((s,x)=>s+x,0)/a.length:0}
function median(a){if(!a.length)return 0;const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);return b.length%2?b[m]:(b[m-1]+b[m])/2}
function parseDrawMinutes(timeText){const t=String(timeText||'').toLowerCase().match(/(\d{1,2}):(\d{2})\s*([ap])/);if(!t)return null;let h=+t[1]%12;if(t[3]==='p')h+=12;return h*60+(+t[2]);}
function formatMinutes(m){if(m==null)return null;m=((Math.round(m)%1440)+1440)%1440;let h=Math.floor(m/60),min=m%60,ap=h>=12?'PM':'AM';h=h%12||12;return `${h}:${String(min).padStart(2,'0')} ${ap}`}
function drawTimeMap(draws){const x=new Map();for(const d of draws)x.set(Number(d.draw_id??d.id),parseDrawMinutes(d.draw_time??d.time));return x}
function statsForGroup(draws,numbers){
  const occ=[];for(const d of draws){const set=new Set(d.numbers||[]);if(numbers.every(n=>set.has(n)))occ.push(Number(d.draw_id??d.id));}
  const gaps=[];for(let i=1;i<occ.length;i++)gaps.push(occ[i]-occ[i-1]);
  const avg=mean(gaps),med=median(gaps),sd=gaps.length?Math.sqrt(mean(gaps.map(x=>(x-avg)**2))):0;
  const cv=avg>0?sd/avg:999;
  const expectedGap=gaps.length?Math.max(1,Math.round((avg+med)/2)):null;
  const latest=Number(draws.at(-1)?.draw_id??draws.at(-1)?.id??0),last=occ.at(-1)||null;
  let center=last&&expectedGap?last+expectedGap:null;if(center){while(center<=latest)center+=expectedGap;}
  const half=gaps.length?Math.max(2,Math.round(sd/2)):null;
  const from=center?Math.max(latest+1,center-half):null,to=center?center+half:null;
  const times=drawTimeMap(draws),latestMinutes=parseDrawMinutes(draws.at(-1)?.draw_time??draws.at(-1)?.time);
  const toClock=id=>id&&latestMinutes!=null?formatMinutes(latestMinutes+(id-latest)*4):null;
  return {numbers,count:occ.length,occurrences:occ,gaps,meanGap:+avg.toFixed(2),medianGap:+med.toFixed(2),minGap:gaps.length?Math.min(...gaps):0,maxGap:gaps.length?Math.max(...gaps):0,standardDeviation:+sd.toFixed(2),coefficientVariation:cv===999?null:+cv.toFixed(3),lastDrawId:last,lastAppearanceTime:last?formatMinutes(times.get(last)):null,sinceLastDraws:last?latest-last:null,sinceLastMinutes:last?(latest-last)*4:null,expectedGapDraws:expectedGap,expectedCenterDrawId:center,expectedFromDrawId:from,expectedToDrawId:to,expectedCenterTime:toClock(center),expectedFromTime:toClock(from),expectedToTime:toClock(to)};
}
function analyzeTopGroups(draws,limit=2){
  if(!Array.isArray(draws)||draws.length<2)return [];
  const candidates=new Set();
  for(let i=0;i<draws.length-1;i++){
    const A=new Set(draws[i].numbers||[]);
    for(let j=i+1;j<draws.length;j++){
      const inter=(draws[j].numbers||[]).filter(n=>A.has(n));
      if(inter.length<5)continue;
      combos5(inter,c=>candidates.add(c.join(',')));
    }
  }
  const out=[];
  for(const key of candidates){const s=statsForGroup(draws,key.split(',').map(Number));if(s.count>=2)out.push(s);}
  out.sort((a,b)=>b.count-a.count||((a.coefficientVariation??999)-(b.coefficientVariation??999))||b.lastDrawId-a.lastDrawId||a.numbers.join(',').localeCompare(b.numbers.join(',')));
  return out.slice(0,limit);
}
function californiaNowParts(date=new Date()){
  const parts=new Intl.DateTimeFormat('en-US',{timeZone:'America/Los_Angeles',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date);
  const o={};for(const p of parts)if(p.type!=='literal')o[p.type]=p.value;
  const hour=+o.hour,minute=+o.minute;
  return {dateKey:`${o.year}-${o.month}-${o.day}`,hour,minute,minutes:hour*60+minute};
}
module.exports={uniqSorted,getDraw,getMany,score,db,statsForGroup,analyzeTopGroups,parseDrawMinutes,formatMinutes,californiaNowParts};
